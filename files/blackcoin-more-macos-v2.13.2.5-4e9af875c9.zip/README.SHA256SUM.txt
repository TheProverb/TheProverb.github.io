blackcoin-more-macos-v2.13.2.5-4e9af875c9

sha256sum blackmore*
4b10a18f4367306e01cf5ad88f7eace883da7bc89ac6f5f14d679d6477165e9a  blackmore-cli
ea9277e37e54f7444c3c5ef852689c4571916299b923dacbdd067563c1b46dc9  blackmore-qt
262f0df2d969f759bfd07cc0ac891f209c60335ddd25d8929afb43d1d988791f  blackmore-tx
1db4eaae85fdfc4b184f5b11aec37595a58374d557672b2e9266437d088f05ca  blackmored

This version solves the "missing utxo" issue. The Berkeley Database has been upgraded to version 6.2.38 

PLEASE BACKUP YOUR WALLET BEFORE UPGRADING! (Wallet.dat) 

- Updated Berkeley DB to 6.2.38
- Updated OpenSSL to 1.0.2u
- Updated fixed seeds
- Changed default port on regtest to 35714

For more info go to https://blackcoinmore.org/
