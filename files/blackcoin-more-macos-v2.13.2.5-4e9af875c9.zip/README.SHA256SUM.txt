blackcoin-more-macos-v2.13.2.5-4e9af875c9

sha256sum blackmore*
b51bc64bc3643dc2ad19fd00fb3eadbf53a382f763a78f28037955d1ab424882  blackmore-cli
84d5b5d5509d125ac3de66765fafa93516621c410bdab604fd1dced659188ca2  blackmore-qt
601cd978a3b86b411b5249af8f7273374e4aaec251b90d6bb6ce828bdb53b3e4  blackmore-tx
44b59ffbfb07e4c0b1b628e504127daaeb34f24073aff2bf047373191bd9976f  blackmored

This version solves the "missing utxo" issue. The Berkeley Database has been upgraded to version 6.2.38 

PLEASE BACKUP YOUR WALLET BEFORE UPGRADING! (Wallet.dat) 

- Updated Berkeley DB to 6.2.38
- Updated OpenSSL to 1.0.2u
- Updated fixed seeds
- Changed default port on regtest to 35714

For more info go to https://blackcoinmore.org/
