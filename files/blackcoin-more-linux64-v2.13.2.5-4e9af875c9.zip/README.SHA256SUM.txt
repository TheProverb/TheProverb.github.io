blackcoin-more-linux64-v2.13.2.5-4e9af875c9

sha256sum blackmore*
3905a1b38bb091eb30e7281d1c640743ea2c4ca0be1da139d23b8c31f5954808  blackmore-cli
2eb912b417014621e74075f0aa08e7dfda1a1d6e67070f47e57cbde589ba1b72  blackmore-qt
b760f043d4e4a0108895683b1390c95b53b56d563c382171d0965d664c17dd0b  blackmore-tx
889d3629be0e4f86c65467e909f3d01b221f307a3247630e6715be0ddfd0918b  blackmored

This version solves the "missing utxo" issue. The Berkeley Database has been upgraded to version 6.2.38 

PLEASE BACKUP YOUR WALLET BEFORE UPGRADING! (Wallet.dat) 

- Updated Berkeley DB to 6.2.38
- Updated OpenSSL to 1.0.2u
- Updated fixed seeds
- Changed default port on regtest to 35714

For more info go to https://blackcoinmore.org/
