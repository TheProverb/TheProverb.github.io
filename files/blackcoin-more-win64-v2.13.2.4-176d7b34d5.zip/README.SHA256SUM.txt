blackcoin-more-win64-v2.13.2.4-176d7b34d5.zip


sha256sum blackmore*

df3b617a52472ae6118e16aa4144f1f9d47c63f04ac9e91a0b2dae64f8d11270  blackmore-cli.exe
d9cb273dfbeb63600ad2c229bab8c8a305b2e0263f630e596cc3e77c3ff0001a  blackmored.exe
688122e9bb7e83e23d0330bfd672297929b1f3f7e0a6899f1893dd4fd349cd29  blackmore-qt.exe
a53a36a957eb10276a78b59204f444ab9f79b6e278cee4ff68410b77493c44d7  blackmore-tx.exe

for more information, go to https://blackcoinmore.org/

