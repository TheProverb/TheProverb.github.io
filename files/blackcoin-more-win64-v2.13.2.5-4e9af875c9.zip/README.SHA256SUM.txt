blackcoin-more-win64-v2.13.2.5-4e9af875c9

sha256sum blackmore*
70f62b5ac00b3eb32fa07a7c25572ba8e2883c14967cec9ce5974a3bf5cdb9fc  blackmore-cli.exe
5a273f4b97a0628d054932b4ac68947d219d7d1178d5d8a90458eeaaaa47a6b2  blackmore-qt.exe
dcfc52ad9c03b61cee13bee4dbfd1a9fb6f25c03a509d7d3ead0aebe80252ce8  blackmore-tx.exe
70eb8a6778cdc32fec6980641eed508cbb0ed2a12f6ddbdc8f9eec970ca68e37  blackmored.exe

This version solves the "missing utxo" issue. The Berkeley Database has been upgraded to version 6.2.38 

PLEASE BACKUP YOUR WALLET BEFORE UPGRADING! (Wallet.dat) 

- Updated Berkeley DB to 6.2.38
- Updated OpenSSL to 1.0.2u
- Updated fixed seeds
- Changed default port on regtest to 35714

For more info go to https://blackcoinmore.org/
