blackcoin-more-armv7-v2.13.2.5-4e9af875c9

sha256sum blackmore*
793898b4cde04bb0b758f04421cfd87218d07528112751fbdd77adf591d29951  blackmore-cli
aa3f0aa59bb71f7fc068f796477f123cae0d5c8a1ac1cc6d2d85b5a02ad0dcbe  blackmore-qt
7c4f5f47f17871e54e4b01cc7995a94327b8ddbe96e7cd54e25f077fafefb151  blackmore-tx
acee1d84038660be599841f3e750d4c05069ea00469f6418181c000cbdc1d8ee  blackmored

This version solves the "missing utxo" issue. The Berkeley Database has been upgraded to version 6.2.38 

PLEASE BACKUP YOUR WALLET BEFORE UPGRADING! (Wallet.dat) 

- Updated Berkeley DB to 6.2.38
- Updated OpenSSL to 1.0.2u
- Updated fixed seeds
- Changed default port on regtest to 35714

For more info go to https://blackcoinmore.org/
