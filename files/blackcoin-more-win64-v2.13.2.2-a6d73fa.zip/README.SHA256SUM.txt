Blackcoin More Win64 v2.13.2.2 BUILD a6d73fa - SHA256SUM:

d8551c465152d2f119ef69a8ea7d87ddb54e753498ec2d1352c4082cddfd68a1  blackmore-cli.exe
fbe4d8407707a15722d64fd3f7cb2311d3550224911a81f2cde393a93a65047e  blackmored.exe
ea0d6d103640391e41adbc384688f53f3e5be77ac6428bfbe2cd01dabba0fe86  blackmore-qt.exe
3a2a0723f014ed7989bba0e809c2be9edc809d328116947a046cad75a7e4483e  blackmore-tx.exe

Please visit https://blackcoinmore.org for more information


